<?php
require 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $id = (int)($_GET['id'] ?? 1);
    $stmt = $pdo->prepare('SELECT id, username, email, phone_no FROM user WHERE id = ? LIMIT 1');
    $stmt->execute([$id]);
    echo json_encode(['success' => true, 'user' => $stmt->fetch(PDO::FETCH_ASSOC)]);
    exit;
}

if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $id = (int)($input['id'] ?? 1);
    $email = trim($input['email'] ?? '');
    $phone = trim($input['phone_no'] ?? '');

    if ($email === '' || $phone === '') {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Email and phone are required']);
        exit;
    }

    $stmt = $pdo->prepare('UPDATE user SET email = ?, phone_no = ? WHERE id = ?');
    $stmt->execute([$email, $phone, $id]);
    echo json_encode(['success' => true, 'message' => 'Profile updated successfully']);
    exit;
}

http_response_code(405);
echo json_encode(['success' => false, 'message' => 'Method not allowed']);
?>
