<?php
require 'db.php';
$stmt = $pdo->query('SELECT id, username, email, phone_no FROM user ORDER BY id');
echo json_encode(['success' => true, 'users' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
?>
