#define PH_SUCCESS                 0
#define PH_ERROR_ADC_READ          0x9001
#define PH_ERROR_NOVALUE           0x9002

#define PH_ADC_MAX_VALUE           1023.0
#define PH_VREF                    5.0

#define PH_FILTER_SIZE             16

#define PH_NEUTRAL_PH              7.00
#define PH_NEUTRAL_VOLTAGE         2.50
#define PH_VOLTAGE_PER_PH          0.18

#define PH_ANALOG_CHANNEL          1
#define PH_ID                      2

#if defined(__cplusplus)
extern "C" {
#endif
     
extern uint32_t PH_Init(void);
extern uint32_t PH_Read(float *ph);


#if defined(__cplusplus)
}
#endif
