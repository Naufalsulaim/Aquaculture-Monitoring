<?php
header('Content-Type: application/json');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/../vendor/autoload.php';

$mail = new PHPMailer(true);

try {
    // SMTP settings
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;

    $mail->Username   = 'sofiabbst@gmail.com';
    $mail->Password   = 'kumu rqoq zgas yuln';

    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    $mail->setFrom('finguard.alert@gmail.com', 'FinGuard Alert');
    $mail->addAddress('sofiabbst@gmail.com');

    // Email content
    $mail->isHTML(true);
    $mail->Subject = "FinGuard Alert: Sensor Threshold Exceeded";
    $mail->Body = buildAlertEmailTemplate($alerts);
    
    $mail->AltBody = "FinGuard Alert: One or more sensors exceeded the safe threshold. Please check the dashboard.";

    $mail->send();

    echo json_encode([
        "success" => true,
        "message" => "Test email sent successfully."
    ]);
} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "Email failed: " . $mail->ErrorInfo
    ]);
}
?>
