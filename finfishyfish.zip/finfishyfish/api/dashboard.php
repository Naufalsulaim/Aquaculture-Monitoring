<?php
header('Content-Type: application/json');

require 'db.php';

function normaliseType($type) {
    $type = strtolower(trim($type));
    if (str_contains($type, 'temp')) return 'temperature';
    if (str_contains($type, 'sal')) return 'salinity';
    if ($type === 'ph' || str_contains($type, 'ph')) return 'ph';
    return $type;
}

try {
    $latestSql = "
        SELECT mt.id AS mid, mt.type, mt.unit, d.value, d.timestamp, t.min_value, t.max_value
        FROM data d
        JOIN meas_t mt ON d.mid = mt.id
        JOIN threshold t ON t.mid = mt.id
        JOIN (
            SELECT mid, MAX(timestamp) AS latest_timestamp
            FROM data
            GROUP BY mid
        ) latest ON latest.mid = d.mid AND latest.latest_timestamp = d.timestamp
        ORDER BY mt.id
    ";

    $latestRows = $pdo->query($latestSql)->fetchAll(PDO::FETCH_ASSOC);

    $latest = [
        'temperature' => null,
        'salinity' => null,
        'ph' => null
    ];

    $alertCount = 0;

    foreach ($latestRows as $row) {
        $key = normaliseType($row['type']);

        if (!array_key_exists($key, $latest)) {
            continue;
        }

        $value = (float)$row['value'];
        $min = (float)$row['min_value'];
        $max = (float)$row['max_value'];

        $alertStatus = 'normal';
        $alertMessage = 'Normal';

        if ($value < $min) {
            $alertStatus = 'below';
            $alertMessage = 'Below min (' . $min . ')';
            $alertCount++;
        } elseif ($value > $max) {
            $alertStatus = 'above';
            $alertMessage = 'Above max (' . $max . ')';
            $alertCount++;
        }

        $latest[$key] = [
            'value' => $value,
            'timestamp' => (int)$row['timestamp'],
            'mid' => (int)$row['mid'],
            'type' => $row['type'],
            'unit' => $row['unit'],
            'min_value' => $min,
            'max_value' => $max,
            'alert_status' => $alertStatus,
            'alert_message' => $alertMessage
        ];
    }

    $tenMinutesAgo = time() - 600;

$trendSql = "
    SELECT 
        FLOOR(d.timestamp / 60) * 60 AS minute_time,
        AVG(CASE WHEN LOWER(mt.type) LIKE '%temp%' THEN d.value END) AS avg_temperature,
        AVG(CASE WHEN LOWER(mt.type) LIKE '%sal%' THEN d.value END) AS avg_salinity,
        AVG(CASE WHEN LOWER(mt.type) = 'ph' OR LOWER(mt.type) LIKE '%ph%' THEN d.value END) AS avg_ph
    FROM data d
    JOIN meas_t mt ON d.mid = mt.id
    WHERE d.timestamp >= :ten_minutes_ago
    GROUP BY minute_time
    ORDER BY minute_time ASC
";

$trendStmt = $pdo->prepare($trendSql);
$trendStmt->execute([
    ':ten_minutes_ago' => $tenMinutesAgo
]);

$trendRows = $trendStmt->fetchAll(PDO::FETCH_ASSOC);

$labels = [];
$trends = [
    'temperature' => [],
    'salinity' => [],
    'ph' => []
];

foreach ($trendRows as $row) {
    $labels[] = date('H:i', (int)$row['minute_time']);

    $trends['temperature'][] = $row['avg_temperature'] !== null
        ? round((float)$row['avg_temperature'], 2)
        : null;

    $trends['salinity'][] = $row['avg_salinity'] !== null
        ? round((float)$row['avg_salinity'], 2)
        : null;

    $trends['ph'][] = $row['avg_ph'] !== null
        ? round((float)$row['avg_ph'], 2)
        : null;
}

    $sensorSql = "
    SELECT 
        s.id,
        s.name,
        s.location,
        s.status,

        (
            SELECT d1.value
            FROM data d1
            JOIN meas_t mt1 ON d1.mid = mt1.id
            WHERE d1.sid = s.id
              AND LOWER(mt1.type) LIKE '%temp%'
            ORDER BY d1.timestamp DESC
            LIMIT 1
        ) AS temperature,

        (
            SELECT t1.min_value
            FROM threshold t1
            JOIN meas_t mt1 ON t1.mid = mt1.id
            WHERE LOWER(mt1.type) LIKE '%temp%'
            LIMIT 1
        ) AS temperature_min,

        (
            SELECT t1.max_value
            FROM threshold t1
            JOIN meas_t mt1 ON t1.mid = mt1.id
            WHERE LOWER(mt1.type) LIKE '%temp%'
            LIMIT 1
        ) AS temperature_max,

        (
            SELECT d2.value
            FROM data d2
            JOIN meas_t mt2 ON d2.mid = mt2.id
            WHERE d2.sid = s.id
              AND LOWER(mt2.type) LIKE '%sal%'
            ORDER BY d2.timestamp DESC
            LIMIT 1
        ) AS salinity,

        (
            SELECT t2.min_value
            FROM threshold t2
            JOIN meas_t mt2 ON t2.mid = mt2.id
            WHERE LOWER(mt2.type) LIKE '%sal%'
            LIMIT 1
        ) AS salinity_min,

        (
            SELECT t2.max_value
            FROM threshold t2
            JOIN meas_t mt2 ON t2.mid = mt2.id
            WHERE LOWER(mt2.type) LIKE '%sal%'
            LIMIT 1
        ) AS salinity_max,

        (
            SELECT d3.value
            FROM data d3
            JOIN meas_t mt3 ON d3.mid = mt3.id
            WHERE d3.sid = s.id
              AND (LOWER(mt3.type) = 'ph' OR LOWER(mt3.type) LIKE '%ph%')
            ORDER BY d3.timestamp DESC
            LIMIT 1
        ) AS ph,

        (
            SELECT t3.min_value
            FROM threshold t3
            JOIN meas_t mt3 ON t3.mid = mt3.id
            WHERE LOWER(mt3.type) = 'ph' OR LOWER(mt3.type) LIKE '%ph%'
            LIMIT 1
        ) AS ph_min,

        (
            SELECT t3.max_value
            FROM threshold t3
            JOIN meas_t mt3 ON t3.mid = mt3.id
            WHERE LOWER(mt3.type) = 'ph' OR LOWER(mt3.type) LIKE '%ph%'
            LIMIT 1
        ) AS ph_max

    FROM sensory s
    ORDER BY s.id
";

$sensors = $pdo->query($sensorSql)->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'latest' => $latest,
        'labels' => $labels,
        'trends' => $trends,
        'sensors' => $sensors,
        'alertCount' => $alertCount
    ]);

} catch (PDOException $e) {
    http_response_code(500);

    echo json_encode([
        'success' => false,
        'message' => 'Dashboard API failed',
        'error' => $e->getMessage()
    ]);
}
?>
