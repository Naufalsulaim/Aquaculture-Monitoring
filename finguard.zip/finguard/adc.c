#include "global.h"

#if defined(__cplusplus)
extern "C"{
#endif

 uint16_t ADC_init(void){
  
  ADMUX = 0x4F;
  ADCSRA = 0x87;
  ADCSRB = 0x00;
  DIDR0 =0X00;

  return ADC_SUCCESS;
 }
 
 uint16_t ADC_Read(uint8_t channel,uint16_t *analog_value){
  if(channel >= ADC_CHANNEL_NUM) return ADC_ERROR_CHANNEL_RANGE;  

  //select channel
  ADMUX = (ADMUX & 0xF0) | (channel & 0x0F);
  //start conversion

  ADCSRA |= 0x40;
  //wait until conversion end when adsc,.low
  while((ADCSRA & 0x40) == 0x40);
  //read adch and adcl return in value
  //*analog_value= ADC;
  *analog_value = ((uint16_t)ADCH << 8) | ADCL;

  return ADC_SUCCESS;
 
}





#if defined(__cpluscplus)
}
#endif