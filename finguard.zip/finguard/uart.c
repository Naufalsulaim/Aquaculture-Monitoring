#include "global.h"

#if defined(__cplusplus)
extern "C"{
  #endif

uint8_t UART_TX_BUF[UART_TX_BUF_SIZE];
uint8_t UART_TX_WR;
uint8_t UART_TX_RD;
uint8_t UART_TX_BYTES;

uint8_t UART_RX_BUF[UART_RX_BUF_SIZE];
uint8_t UART_RX_WR;
uint8_t UART_RX_RD;
uint8_t UART_RX_BYTES;

//enable serial port
uint16_t UART_init(void){
  uint8_t dummy = UDR0;

  UCSR0B=	0x98; // enable TX AND RECEIVER BIT 7 ENABLE INTTERUPT WHEN GET BYTE
  UCSR0C = 0x06; //8-bit, async, 1 stop-bit,no parity
  UBRR0 = 103; //9600 baudrate @16Mhz

  UART_TX_WR =     0; 
  UART_TX_RD =     0; 
  UART_TX_BYTES =  0;

  UART_RX_WR=0;
  UART_RX_RD=0;
  UART_RX_BYTES=0;

  return UART_SUCCESS;
}

uint16_t UART_Write(uint8_t t_byte){
    if((UART_TX_BYTES + 1)> UART_TX_BUF_SIZE) return UART_ERROR_TX_BUF_FULL;
   
    UART_TX_BUF[UART_TX_WR] = t_byte; //update dlm buffer character dekat string
    UART_TX_WR= (UART_TX_WR + 1) & (UART_TX_BUF_SIZE - 1); //ni increase write pointer by 1 inside 32 bit
    UART_TX_BYTES++; //increase byte for check
    
    UCSR0B |= 0x20; // enable interrypts after all write done
  return UART_SUCCESS;
}

uint16_t UART_Write_String(uint8_t *str, uint8_t size){
  uint8_t i;
  uint8_t intr_state = UCSR0B & 0x20; //record state of interrupt ( if set UART is busy)
  
  if((size  + UART_TX_BYTES) > UART_TX_BUF_SIZE) return UART_ERROR_TX_BUF_FULL;

 
  UCSR0B &= ~0x20;//disable interrupts for let thing be done
  for(i= 0; i < size; i++){
    UART_TX_BUF[UART_TX_WR] = str[i]; //update dlm buffer character dekat string
    UART_TX_WR= (UART_TX_WR + 1) & (UART_TX_BUF_SIZE - 1); //ni increase write pointer by 1 inside 32 bit
    UART_TX_BYTES++; //increase byte for check
  }

  if (intr_state == 0) { //interupt not enbaled UART is free(can write byte)
    UDR0 = UART_TX_BUF[UART_TX_RD];
    UART_TX_RD= (UART_TX_RD + 1) &(UART_TX_BUF_SIZE - 1);
    UART_TX_BYTES--;
  }

  UCSR0B |= 0x20; // enable interrypts after all write done

  return UART_SUCCESS;
}

ISR(USART_UDRE_vect){
  if(UART_TX_BYTES > 0){
    UDR0 = UART_TX_BUF[UART_TX_RD];
    UART_TX_RD= (UART_TX_RD + 1) &(UART_TX_BUF_SIZE - 1);
    UART_TX_BYTES--;
  }
  else  UCSR0B &= ~0x20;
}

ISR(USART_RX_vect){
  uint8_t byte=UDR0;
  if(UART_RX_BYTES < UART_RX_BUF_SIZE){
    UART_RX_BUF[UART_RX_WR]= byte;
    UART_RX_WR= (UART_RX_WR + 1) &(UART_RX_BUF_SIZE - 1);
    UART_RX_BYTES++;
  }
}

uint16_t UART_Read(uint8_t *r_byte){
  if(UART_RX_BYTES == 0 ) return UART_ERROR_RX_BUF_EMPTY;
  //return 1 byte from UART_RX_BUF to the user via *byte
  *r_byte= UART_RX_BUF[UART_RX_RD];
  //update UART_RX_BUF_RD and UART_rx_BYTEs accordingly
  UART_RX_RD = (UART_RX_RD + 1) &(UART_RX_BUF_SIZE - 1);
  UART_RX_BYTES--;
  
  return UART_SUCCESS;
}
/*
uint16_t UART_Process(void){
  if(UART_TX_BYTES > 0){ //got bytes?
    if((UCSR0A & 0x20) > 0){ //can Tx?
      UDR0 =   UART_TX_BUF[UART_TX_RD];//transmit str[i] 
      UART_TX_RD= (UART_TX_RD + 1) &(UART_TX_BUF_SIZE - 1);
      UART_TX_BYTES--; //decrease byte for check
    }
  }

  return UART_SUCCESS;
}
*/
#if defined(__cplusplus)
}
#endif