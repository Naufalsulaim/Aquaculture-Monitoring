#include "global.h"

#if defined(__cplusplus)
extern "C"{
  #endif


uint16_t TIMER1_init(void){
  TCCR1A = 0x00;
  TCCR1B = 0x02;
  TCNT1 = 0;

  return TIMER1_SUCCESS;
}

uint16_t TIMER1_GetMicros(void){
  return TCNT1 >> 1;
}

void TIMER1_Delay(uint16_t us){
  TCNT1=0;

  while(TCNT1 < (us << 1));
}



#if defined(__cplusplus)
}
#endif