#include "global.h"

static uint16_t ADC_Value[PH_FILTER_SIZE] = {0};
static uint8_t ADC_ptr = 0;
static uint32_t ADC_sum = 0;


uint32_t PH_Init(void) {
    uint8_t i;

    for(i = 0; i < PH_FILTER_SIZE; i++) {
        ADC_Value[i] = 0;
    }

    ADC_ptr = 0;
    ADC_sum = 0;

    return PH_SUCCESS;
}

uint32_t PH_Read(float *ph) {
    uint32_t ADC_avg;
    float voltage;
    float ph_value;

    if(ph == NULL) {
        return PH_ERROR_NOVALUE;
    }

    ADC_sum -= ADC_Value[ADC_ptr];
    ADC_Read(PH_ANALOG_CHANNEL, &ADC_Value[ADC_ptr]);
    ADC_sum += ADC_Value[ADC_ptr];
    ADC_avg = ADC_sum / PH_FILTER_SIZE;
    ADC_ptr = (ADC_ptr + 1) & (PH_FILTER_SIZE - 1);

    voltage = ((float)ADC_avg * PH_VREF) / PH_ADC_MAX_VALUE;
    ph_value = PH_NEUTRAL_PH - ((voltage - PH_NEUTRAL_VOLTAGE) / PH_VOLTAGE_PER_PH);

    *ph = ph_value;

    return PH_SUCCESS;
}