#include "global.h"

#if defined(__cplusplus)
extern "C"{
  #endif

 uint8_t SWUART_TX_BYTES; //denotes number of bytes in the tx buffer left to transmit
 uint8_t SWUART_RX_BYTES;
 
SWUART_STATE_e SWUART_TX_STATE;
SWUART_STATE_e SWUART_RX_STATE;

uint8_t SWUART_TX_BUF[SWUART_TX_BUF_SIZE]; //transmit buffer
uint8_t SWUART_TX_WR;
uint8_t SWUART_TX_RD;
uint8_t SWUART_TX_BYTES; 

uint8_t SWUART_RX_BUF[SWUART_RX_BUF_SIZE]; //transmit buffer
uint8_t SWUART_RX_WR;
uint8_t SWUART_RX_RD;
uint8_t SWUART_RX_BYTES;

uint16_t SWUART_init(void){
  SWUART_TX_STATE = SWUART_STATE_IDLE;
  SWUART_TX_WR =     0; 
  SWUART_TX_RD =     0; 
  SWUART_TX_BYTES =  0;

  SWUART_RX_STATE = SWUART_STATE_IDLE;
  SWUART_RX_WR =     0; 
  SWUART_RX_RD =     0; 
  SWUART_RX_BYTES =  0;

  GPIO_WRITE(SWUART_TX_PIN, HIGH);
  GPIO_MODE(SWUART_TX_PIN, OUTPUT);

  GPIO_MODE(SWUART_RX_PIN, INPUT);

  return SWUART_SUCCESS;
}

uint16_t SWUART_Process(void){
  static uint8_t tx_cycle;
  static uint16_t tx_byte;
  uint8_t pin;
  static uint8_t rx_cycle;
  static uint16_t rx_byte;

  if(SWUART_TX_STATE == SWUART_STATE_IDLE){      //tx is idle
    if(SWUART_TX_BYTES > 0){                        //got  bytes to transmit
      tx_cycle =0;
      tx_byte = (SWUART_TX_BUF[SWUART_TX_RD] << 1) | 0X0200;                   
      SWUART_TX_STATE= SWUART_STATE_BUSY;        //change state to busy stae on next call of swuart_process
    }
  }
  else if (SWUART_TX_STATE == SWUART_STATE_BUSY){
    if(tx_cycle >= 39) {
      SWUART_TX_RD = (SWUART_TX_RD + 1) & (SWUART_TX_BUF_SIZE - 1);
      SWUART_TX_BYTES--;
      GPIO_WRITE(SWUART_TX_PIN, HIGH); 
      SWUART_TX_STATE = SWUART_STATE_IDLE;
    }
    else {
      if((tx_cycle & 3) ==0){ // 4cycle sample of bit
        if(tx_byte & 0x01 == 0x01){ //check bit high or low
          GPIO_WRITE(SWUART_TX_PIN, HIGH);
        }
        else{
          GPIO_WRITE(SWUART_TX_PIN, LOW);
        }
        tx_byte = tx_byte >> 1;
      }
    }
    tx_cycle++;
  }
  else Error_Handler(SWUART_ERROR_TX_FSM, __LINE__,__FILE__); //should never come here

  if(SWUART_RX_STATE == SWUART_STATE_IDLE){
    //read received pin anf if low go to busy state
    GPIO_READ(SWUART_RX_PIN, &pin);
    if(pin == LOW){
      rx_cycle=1;
      rx_byte=0;
      SWUART_RX_STATE = SWUART_STATE_BUSY;
    }
  }
  else if (SWUART_RX_STATE == SWUART_STATE_BUSY){
    if(rx_cycle >= 39){
      if(((rx_byte & 0x0001) == 0) && ((rx_byte & 0x200)==0x0200)){
        if(SWUART_RX_BYTES < SWUART_RX_BUF_SIZE){
          rx_byte >>=1;
          SWUART_RX_BUF[SWUART_RX_WR]= (uint8_t) rx_byte;
          SWUART_RX_WR= (SWUART_RX_WR + 1) &(SWUART_RX_BUF_SIZE - 1);
          SWUART_RX_BYTES++;
        }
      }
      SWUART_RX_STATE = SWUART_STATE_IDLE;
    }
    else{
      if((rx_cycle & 3) == 2){
        GPIO_READ(SWUART_RX_PIN, &pin);
        if(pin == HIGH){
          rx_byte |= 0x0400;
        }
        rx_byte = rx_byte >> 1;
      }
    }
    rx_cycle++;
  }
  else Error_Handler(SWUART_ERROR_RX_FSM, __LINE__,__FILE__);


  return SWUART_SUCCESS;
}

uint16_t SWUART_Write(uint8_t t_byte){
  if((SWUART_TX_BYTES + 1)> SWUART_TX_BUF_SIZE) return SWUART_ERROR_TX_BUF_FULL;
   
  SWUART_TX_BUF[SWUART_TX_WR] = t_byte; //update dlm buffer character dekat string
  SWUART_TX_WR= (SWUART_TX_WR + 1) & (SWUART_TX_BUF_SIZE - 1); //ni increase write pointer by 1 inside 32 bit
  SWUART_TX_BYTES++; //increase byte for check

  return SWUART_SUCCESS;
}

uint16_t SWUART_Write_String(uint8_t *str, uint8_t size){
  uint8_t i;
  
  
  if((size  + SWUART_TX_BYTES) > SWUART_TX_BUF_SIZE) return SWUART_ERROR_TX_BUF_FULL;

 
  for(i= 0; i < size; i++){
    SWUART_TX_BUF[SWUART_TX_WR] = str[i]; //update dlm buffer character dekat string
    SWUART_TX_WR= (SWUART_TX_WR + 1) & (SWUART_TX_BUF_SIZE - 1); //ni increase write pointer by 1 inside 32 bit
    SWUART_TX_BYTES++; //increase byte for check
  }

 
  return SWUART_SUCCESS;
}

uint16_t SWUART_Read(uint8_t *r_byte){
  if(SWUART_RX_BYTES == 0 ) return SWUART_ERROR_RX_BUF_EMPTY;
  //return 1 byte from SWUART_RX_BUF to the user via *byte
  *r_byte= SWUART_RX_BUF[SWUART_RX_RD];
  //update UART_RX_BUF_RD and UART_rx_BYTEs accordingly
  SWUART_RX_RD = (SWUART_RX_RD + 1) &(SWUART_RX_BUF_SIZE - 1);
  SWUART_RX_BYTES--;
  
  return SWUART_SUCCESS;
}

#if defined(__cpluscplus)
}
#endif