#define ADC_SUCCESS             0
#define ADC_ERROR_INIT          0X4000
#define ADC_ERROR_CHANNEL_RANGE 0X4001

#define ADC_CHANNEL_NUM         6
#define ADC_BUF_SIZE         16


#if defined(__cplusplus)
extern "C"{
#endif
extern uint16_t ADC_init(void);
extern uint16_t ADC_Read(uint8_t channel,uint16_t *analog_value);

#if defined(__cplusplus)
}
#endif
