#define TIMER2_SUCCESS 0
#define TIMER2_ERROR_INT 0X2000

#if defined(__cplusplus)
extern "C"{
#endif

extern uint16_t TIMER2_init(void);
extern volatile uint32_t SYS_TICK;

#if defined(__cplusplus)
}
#endif
