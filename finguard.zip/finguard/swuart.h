#define SWUART_SUCCESS 0
#define SWUART_ERROR_INT          0X7000
#define SWUART_ERROR_TX_BUF_FULL  0X7001
#define SWUART_ERROR_RX_BUF_EMPTY 0X7002
#define SWUART_ERROR_TX_FSM       0x7003
#define SWUART_ERROR_RX_FSM       0x7004

#define SWUART_TX_BUF_SIZE 512
#define SWUART_RX_BUF_SIZE 64

#define SWUART_TX_PIN      3
#define SWUART_RX_PIN      2

#if defined(__cplusplus)
extern "C"{
#endif

typedef enum{         //selfcreate data type 9of type enum)
  SWUART_STATE_IDLE,
  SWUART_STATE_BUSY
} SWUART_STATE_e;  //name of data type



extern uint8_t SWUART_TX_BYTES; //denotes number of bytes in the tx buffer left to transmit
extern uint8_t SWUART_RX_BYTES;


extern uint16_t SWUART_init(void);
extern uint16_t SWUART_Process(void);
extern uint16_t SWUART_Write(uint8_t t_byte);
extern uint16_t SWUART_Write_String(uint8_t *str, uint8_t size);
extern uint16_t SWUART_Read(uint8_t *r_byte);


#if defined(__cplusplus)
}
#endif
