<?php
require 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    try {
        $sql = "SELECT t.id, t.mid, mt.type, mt.unit, t.min_value, t.max_value
                FROM threshold t
                JOIN meas_t mt ON t.mid = mt.id
                ORDER BY t.mid";
        echo json_encode(['success' => true, 'thresholds' => $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC)]);
        exit;
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to load thresholds', 'error' => $e->getMessage()]);
        exit;
    }
}

if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $thresholds = $input['thresholds'] ?? [];

    if (empty($thresholds)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'No threshold data received.']);
        exit;
    }

    try {
        $pdo->beginTransaction();
        $checkStmt = $pdo->prepare('SELECT id FROM threshold WHERE mid = ? LIMIT 1');
        $updateStmt = $pdo->prepare('UPDATE threshold SET min_value = ?, max_value = ? WHERE mid = ?');
        $insertStmt = $pdo->prepare('INSERT INTO threshold (mid, min_value, max_value) VALUES (?, ?, ?)');

        foreach ($thresholds as $row) {
            $mid = (int)$row['mid'];
            $min = (float)$row['min_value'];
            $max = (float)$row['max_value'];

            $checkStmt->execute([$mid]);
            if ($checkStmt->fetch(PDO::FETCH_ASSOC)) {
                $updateStmt->execute([$min, $max, $mid]);
            } else {
                $insertStmt->execute([$mid, $min, $max]);
            }
        }

        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Sensor settings saved successfully!']);
        exit;
    } catch (PDOException $e) {
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to save thresholds.', 'error' => $e->getMessage()]);
        exit;
    }
}

http_response_code(405);
echo json_encode(['success' => false, 'message' => 'Method not allowed']);
?>
