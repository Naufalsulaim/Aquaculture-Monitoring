#define UART_SUCCESS 0
#define UART_ERROR_INT 0X3000
#define UART_ERROR_TX_BUF_FULL 0X3001
#define UART_ERROR_RX_BUF_EMPTY 0X3002

#define UART_TX_BUF_SIZE 512 //Must be 2^N size
#define UART_RX_BUF_SIZE 64

#if defined(__cplusplus)
extern "C"{
#endif

extern uint8_t UART_TX_BYTES; //denotes number of bytes in the tx buffer left to transmit
extern uint8_t UART_RX_BYTES; //denotes number of bytes in the rx buffer left to read

extern uint16_t UART_init(void);
extern uint16_t UART_Write(uint8_t t_byte);
extern uint16_t UART_Write_String(uint8_t *str, uint8_t size);
extern uint16_t UART_Read(uint8_t *r_byte);

//extern uint16_t UART_Process(void);


#if defined(__cplusplus)
}
#endif
