#include "global.h"

#if defined(__cplusplus)
extern "C"{
  #endif

//volatile uint32_t TIMER0_TICK;

uint16_t TIMER0_init(void){
  TCCR0A = 0x02;
  TCCR0B = 0x02; 
  OCR0A = 51; //gives 38461 Hz@16Mhz (0,16% error)
  TIFR0 = 0x02;
  TIMSK0 = 0x02;
  //TIMER0_TICK = 0;

  return TIMER0_SUCCESS;
}

ISR(TIMER0_COMPA_vect){
  SWUART_Process();
  //TIMER0_TICK++;
}

#if defined(__cpluscplus)
}
#endif