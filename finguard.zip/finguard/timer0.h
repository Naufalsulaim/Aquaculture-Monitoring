#define TIMER0_SUCCESS    0
#define TIMER0_ERROR_INT  0X6000

#if defined(__cplusplus)
extern "C"{
#endif

extern uint16_t TIMER0_init(void);
//extern volatile uint32_t TIMER0_TICK;

#if defined(__cplusplus)
}
#endif
