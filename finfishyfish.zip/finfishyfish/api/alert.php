<?php
require_once 'db.php';

function normaliseType($type) {
    $type = strtolower(trim($type));
    if (str_contains($type, 'temp')) return 'temperature';
    if (str_contains($type, 'sal')) return 'salinity';
    if ($type === 'ph' || str_contains($type, 'ph')) return 'ph';
    return $type;
}

try {
    $sql = "
        SELECT mt.id AS mid, mt.type, mt.unit, d.value, t.min_value, t.max_value
        FROM data d
        JOIN meas_t mt ON d.mid = mt.id
        JOIN threshold t ON t.mid = mt.id
        JOIN (
            SELECT mid, MAX(timestamp) AS latest_timestamp
            FROM data
            GROUP BY mid
        ) latest ON latest.mid = d.mid AND latest.latest_timestamp = d.timestamp
        ORDER BY mt.id
    ";

    $rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    $alerts = [];

    foreach ($rows as $row) {
        $value = (float)$row['value'];
        $min = (float)$row['min_value'];
        $max = (float)$row['max_value'];
        $type = ucfirst(normaliseType($row['type']));

        if ($value < $min) {
            $alerts[] = ['mid' => (int)$row['mid'], 'type' => $type, 'status' => 'below', 'message' => $type . ' is below minimum threshold. Current value: ' . $value . ', Minimum: ' . $min];
        } elseif ($value > $max) {
            $alerts[] = ['mid' => (int)$row['mid'], 'type' => $type, 'status' => 'above', 'message' => $type . ' exceeded maximum threshold. Current value: ' . $value . ', Maximum: ' . $max];
        }
    }

    echo json_encode(['success' => true, 'alert_count' => count($alerts), 'alerts' => $alerts]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to check sensor alerts', 'error' => $e->getMessage()]);
}
?>
