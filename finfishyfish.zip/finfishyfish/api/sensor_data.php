<?PHP
include "db.php";

$sql_handle=@mysqli_connect($host,$username,$password);
if(!$sql_handle) {$code=1; goto end;}


$sql_result=@@mysqli_select_db($sql_handle,$dbname);
if(!$sql_result) { $code=2; goto end;}
/*
$sql_query = "INSERT INTO data VALUES(NULL,2,0,1778636922,32.4)";
$sql_result = mysqli_query($sql_handle,$sql_query);
if(!$sql_result) echo "<P>ERROR query";
else echo "<P>Query Successful";
*/
//cannot use this style in real world
//$_POST['data'];
//<sid>!<mid>,<timestamp>,<value>;<mid>,<timestamp>,<value>
$row = explode(";",$_POST['data']);
$sql_query="INSERT INTO data VALUES";

foreach($row as $data) $sql_query .= "(NULL," . $data . "),";
$sql_query=substr($sql_query,0,-1);


if($SITE_DEBUG) echo "<P>" . $sql_query;
//exit;//just fochecking if nak upload to db remove this

$sql_result = @mysqli_query($sql_handle,$sql_query);
if(!$sql_result) {$code=3; goto end;}

$code=0;


end:
echo $code;

?>
