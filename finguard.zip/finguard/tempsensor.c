#include "global.h"

#if defined(__cplusplus)
extern "C"{
#endif

static void OneWire_Low(void){
  GPIO_MODE(DS18B20_PIN,OUTPUT);
  GPIO_WRITE(DS18B20_PIN,LOW);
}

static void OneWire_Release(void){
  GPIO_MODE(DS18B20_PIN,INPUT);
}


static uint8_t OneWire_ReadPin(void){
  uint8_t value;

  GPIO_READ(DS18B20_PIN, &value);

  return value;
}

static uint8_t OneWire_Reset(void){
  uint8_t presence;

  OneWire_Low();
  TIMER1_Delay(480);

  OneWire_Release();
  TIMER1_Delay(70);
    
  presence = !OneWire_ReadPin();
  TIMER1_Delay(410);

  if(!presence) return DS18B20_ERROR_SENSOR;
  else {
    
    return DS18B20_SUCCESS;
  }
}

static void OneWire_WriteBit(uint8_t bit){
  if(bit){
    OneWire_Low();
    TIMER1_Delay(10);
    OneWire_Release();
    TIMER1_Delay(55);
  }
  else{
    OneWire_Low();
    TIMER1_Delay(65);
    OneWire_Release();
    TIMER1_Delay(5);
  }
}

static uint8_t OneWire_ReadBit(void)
{
    uint8_t bit;

    OneWire_Low();
    TIMER1_Delay(3);

    OneWire_Release();
    TIMER1_Delay(10);

    bit = OneWire_ReadPin();

    TIMER1_Delay(53);

    return bit;
}

static void OneWire_WriteByte(uint8_t data)
{
    uint8_t i;

    for (i = 0; i < 8; i++)
    {
        OneWire_WriteBit(data & 0x01);
        data >>= 1;
    }
}

static uint8_t OneWire_ReadByte(void)
{
    uint8_t i;
    uint8_t data = 0;

    for (i = 0; i < 8; i++)
    {
        if (OneWire_ReadBit())
        {
            data |= (1 << i);
        }
    }

    return data;
}

    
uint16_t DS18B20_Init(void){
  
  OneWire_Release();
  
  return DS18B20_SUCCESS;
}

uint16_t DS18B20_RequestTemperature(void){
  if (OneWire_Reset() != DS18B20_SUCCESS) return DS18B20_ERROR_SENSOR;

  OneWire_WriteByte(DS18B20_SKIP_ROM);
  OneWire_WriteByte(DS18B20_CONVERT_TEMP);

  return DS18B20_SUCCESS;
}


uint16_t DS18B20_GetTemperatureC(float *temperature){
  uint8_t lsb;
  uint8_t msb;
  int16_t raw;
  char str[64];

  if(temperature == NULL) return DS18B20_ERROR_SENSOR;
  if (OneWire_Reset() != DS18B20_SUCCESS) return DS18B20_ERROR_SENSOR;
  
  OneWire_WriteByte(DS18B20_SKIP_ROM);
  OneWire_WriteByte(DS18B20_READ_SCRATCHPAD);

  lsb = OneWire_ReadByte();
  msb = OneWire_ReadByte();

  raw = ((int16_t)msb << 8) | lsb;

  *temperature = raw/16.0;

  return DS18B20_SUCCESS;
}






#if defined(__cplusplus)
}
#endif