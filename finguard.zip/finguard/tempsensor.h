#define DS18B20_SUCCESS            0
#define DS18B20_ERROR_INIT         0X5000
#define DS18B20_ERROR_SENSOR       0X5001

#define DS18B20_SKIP_ROM        0xCC
#define DS18B20_CONVERT_TEMP    0X44
#define DS18B20_READ_SCRATCHPAD 0XBE

#define DS18B20_PIN     6
#define TEMP_ID         0

#if defined(__cplusplus)
extern "C"{
#endif

extern uint16_t DS18B20_Init(void);
extern uint16_t DS18B20_RequestTemperature(void);
extern uint16_t DS18B20_GetTemperatureC(float *temperature);

#if defined(__cplusplus)
}
#endif