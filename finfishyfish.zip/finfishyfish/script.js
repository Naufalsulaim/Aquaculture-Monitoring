// LOGIN SYSTEM
const currentPage = window.location.pathname.split('/').pop() || 'index.html';
const isLoggedIn = localStorage.getItem('isLoggedIn');

const protectedPages = ['index.html', 'user.html', 'settings.html', 'profile.html'];

if (protectedPages.includes(currentPage) && isLoggedIn !== 'true') {
	window.location.href = 'login.html';
}

if (currentPage === 'login.html' && isLoggedIn === 'true') {
	window.location.href = 'index.html';
}

// checks email from user table
const loginForm = document.getElementById('login-form');

if (loginForm) {
	loginForm.addEventListener('submit', async function (e) {
		e.preventDefault();

		const email = document.getElementById('email').value.trim();
		const loginError = document.getElementById('login-error');
		loginError.textContent = '';

		try {
			const response = await fetch('api/login.php', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({ email })
			});

			const result = await response.json();

			if (result.success) {
				localStorage.setItem('isLoggedIn', 'true');
				localStorage.setItem('user', JSON.stringify(result.user));
				window.location.href = 'index.html';
			} else {
				loginError.textContent = result.message || 'Invalid email address. Please try again.';
			}
		} catch (error) {
			loginError.textContent = 'Cannot connect to server. Open this project through localhost, not directly as a file.';
		}
	});
}

// LOGOUT
const logoutBtn = document.querySelector('.logout');
if (logoutBtn) {
	logoutBtn.addEventListener('click', function (e) {
		e.preventDefault();
		localStorage.removeItem('isLoggedIn');
		localStorage.removeItem('user');
		window.location.href = 'login.html';
	});
}

// SIDEBAR ACTIVE MENU
const allSideMenu = document.querySelectorAll('#sidebar .side-menu.top li a');
allSideMenu.forEach(item => {
	const li = item.parentElement;
	item.addEventListener('click', function () {
		allSideMenu.forEach(i => i.parentElement.classList.remove('active'));
		li.classList.add('active');
	});
});

// TOGGLE SIDEBAR
const menuBar = document.querySelector('#content nav .bx.bx-menu');
const sidebar = document.getElementById('sidebar');
if (menuBar && sidebar) {
	menuBar.addEventListener('click', function () {
		sidebar.classList.toggle('hide');
	});
}
if (sidebar && window.innerWidth < 768) sidebar.classList.add('hide');


function setText(id, value) {
	const element = document.getElementById(id);
	if (element) element.textContent = value;
}

function updateAlertCount(count) {
	setText('alert-count', count ?? 0);
}

// DASHBOARD DATA FROM MYSQL

let dashboardCharts = {};
let dashboardRefreshTimer = null;
let selectedSensorId = null;
let latestSensors = [];

async function loadDashboard() {
	if (!document.getElementById('temperatureChart')) return;

	try {
		const response = await fetch('api/dashboard.php');
		const result = await response.json();

		if (!result.success) throw new Error(result.message || 'Dashboard API failed');

		setText('latest-temperature', result.latest.temperature ? result.latest.temperature.value : '--');
		setText('latest-salinity', result.latest.salinity ? result.latest.salinity.value : '--');
		setText('latest-ph', result.latest.ph ? result.latest.ph.value : '--');
		
		updateLiveBoxAlert('temperature', result.latest.temperature);
		updateLiveBoxAlert('salinity', result.latest.salinity);
		updateLiveBoxAlert('ph', result.latest.ph);
		
		updateAlertCount(result.alertCount);

		const sensorList = document.getElementById('sensor-list');

if (sensorList) {
	latestSensors = result.sensors || [];
	sensorList.innerHTML = '';

	latestSensors.forEach(sensor => {
		const isActive = sensor.status === 'active';

		const li = document.createElement('li');
		li.className = isActive ? 'completed sensor-clickable' : 'not-completed sensor-clickable';
		li.dataset.sensorId = sensor.id;

		if (selectedSensorId === Number(sensor.id)) {
			li.classList.add('selected-sensor');
		}

		li.innerHTML = `
			<p>
				${sensor.name} - Location ${sensor.location}
				<span class="${isActive ? 'sensor-active-label' : 'sensor-inactive-label'}">
					(${sensor.status})
				</span>
			</p>
			<i class='bx bx-dots-vertical-rounded'></i>
		`;

		sensorList.appendChild(li);
	});
}

if (result.sensors && result.sensors.length > 0) {
	let selectedSensor = null;

	if (selectedSensorId === null) {
		selectedSensor = result.sensors.find(sensor => sensor.status === 'active');

		if (selectedSensor) {
			selectedSensorId = Number(selectedSensor.id);
		}
	} else {
		selectedSensor = result.sensors.find(sensor => Number(sensor.id) === selectedSensorId);
	}

	if (selectedSensor) {
		showSensorOnMainCards(selectedSensor);
	}
}

		createLineChart('temperatureChart', 'Temperature °C', result.labels, result.trends.temperature);
		createLineChart('salinityChart', 'Salinity ppm', result.labels, result.trends.salinity);
		createLineChart('phChart', 'pH Level', result.labels, result.trends.ph);
	} catch (error) {
		console.error(error);
		setText('latest-temperature', 'Error');
		setText('latest-salinity', 'Error');
		setText('latest-ph', 'Error');
	}
}

document.addEventListener('click', function (e) {
	const sensorItem = e.target.closest('.sensor-clickable');

	if (!sensorItem) return;

	const sensorId = Number(sensorItem.dataset.sensorId);
	const sensor = latestSensors.find(item => Number(item.id) === sensorId);

	if (!sensor) {
		console.error('Sensor not found:', sensorId);
		return;
	}

	selectedSensorId = sensorId;
	showSensorOnMainCards(sensor);

	document.querySelectorAll('.sensor-clickable').forEach(item => {
		item.classList.remove('selected-sensor');
	});

	sensorItem.classList.add('selected-sensor');
});

function createLineChart(canvasId, label, labels, data) {
	const canvas = document.getElementById(canvasId);
	if (!canvas) return;

	if (dashboardCharts[canvasId]) {
		dashboardCharts[canvasId].data.labels = labels;
		dashboardCharts[canvasId].data.datasets[0].data = data;
		dashboardCharts[canvasId].update();
		return;
	}

	dashboardCharts[canvasId] = new Chart(canvas, {
		type: 'line',
		data: {
			labels,
			datasets: [{
				label,
				data,
				borderWidth: 3,
				tension: 0.4,
				pointRadius: 3
			}]
		},
		options: {
			responsive: true,
			maintainAspectRatio: false,
			animation: false,
			plugins: {
				legend: { display: false }
			},
			scales: {
				x: {
					title: {
						display: true,
						text: 'Last 10 Minutes'
					}
				},
				y: {
					beginAtZero: false
				}
			}
		}
	});
}

function showSensorOnMainCards(sensor) {
	const isActive = sensor.status === 'active';

	if (!isActive) {
		setSensorCardValue('temperature', '--', 'Inactive', 'inactive');
		setSensorCardValue('salinity', '--', 'Inactive', 'inactive');
		setSensorCardValue('ph', '--', 'Inactive', 'inactive');
		updateSelectedSensorAlertBox(sensor, []);
		return;
	}

	const alerts = [];

	const tempAlert = getSensorAlertStatus(
		'Temperature',
		sensor.temperature,
		sensor.temperature_min,
		sensor.temperature_max,
		'°C'
	);

	const salinityAlert = getSensorAlertStatus(
		'Salinity',
		sensor.salinity,
		sensor.salinity_min,
		sensor.salinity_max,
		'ppt'
	);

	const phAlert = getSensorAlertStatus(
		'pH',
		sensor.ph,
		sensor.ph_min,
		sensor.ph_max,
		''
	);

	setSensorCardValue(
		'temperature',
		formatReading(sensor.temperature),
		tempAlert.message,
		tempAlert.status
	);

	setSensorCardValue(
		'salinity',
		formatReading(sensor.salinity),
		salinityAlert.message,
		salinityAlert.status
	);

	setSensorCardValue(
		'ph',
		formatReading(sensor.ph),
		phAlert.message,
		phAlert.status
	);

	if (tempAlert.status !== 'normal') alerts.push(tempAlert);
	if (salinityAlert.status !== 'normal') alerts.push(salinityAlert);
	if (phAlert.status !== 'normal') alerts.push(phAlert);

	updateSelectedSensorAlertBox(sensor, alerts);
}

function formatReading(value) {
	if (value === null || value === undefined || value === '') return '--';
	return Number(value).toFixed(2);
}

function getSensorAlertStatus(label, value, min, max, unit) {
	if (value === null || value === undefined || value === '') {
		return {
			status: 'inactive',
			message: 'No reading',
			alertText: `${label} has no reading.`
		};
	}

	const reading = Number(value);
	const minValue = Number(min);
	const maxValue = Number(max);

	if (reading < minValue) {
		return {
			status: 'below',
			message: `Below min (${minValue})`,
			alertText: `${label} is below minimum threshold. Current value: ${reading}, Minimum: ${minValue}${unit ? ' ' + unit : ''}`
		};
	}

	if (reading > maxValue) {
		return {
			status: 'above',
			message: `Above max (${maxValue})`,
			alertText: `${label} exceeded maximum threshold. Current value: ${reading}, Maximum: ${maxValue}${unit ? ' ' + unit : ''}`
		};
	}

	return {
		status: 'normal',
		message: 'Normal',
		alertText: ''
	};
}

function setSensorCardValue(type, value, message, status) {
	setText(`latest-${type}`, value);
	setText(`${type}-status`, message);

	const card = document.getElementById(`${type}-card`);
	if (!card) return;

	card.classList.remove('sensor-normal', 'sensor-alert');

	if (status === 'above' || status === 'below' || status === 'inactive') {
		card.classList.add('sensor-alert');
	} else {
		card.classList.add('sensor-normal');
	}
}

function updateSelectedSensorAlertBox(sensor, alerts) {
	const alertBox = document.getElementById('alert-box');
	const alertList = document.getElementById('alert-list');

	if (!alertBox || !alertList) return;

	alertList.innerHTML = '';

	if (!sensor || sensor.status !== 'active') {
		alertBox.style.display = 'none';
		return;
	}

	if (alerts.length === 0) {
		alertBox.style.display = 'none';
		return;
	}

	alertBox.style.display = 'block';

	alerts.forEach(alert => {
		const li = document.createElement('li');
		li.textContent = `${sensor.name}: ${alert.alertText}`;
		alertList.appendChild(li);
	});
}

function setInactiveCard(type) {
	const card = document.getElementById(`${type}-card`);
	const status = document.getElementById(`${type}-status`);

	if (!card || !status) return;

	card.classList.remove('sensor-normal', 'sensor-alert');
	card.classList.add('sensor-alert');
	status.textContent = 'Inactive';
}

function setNormalCard(type) {
	const card = document.getElementById(`${type}-card`);
	const status = document.getElementById(`${type}-status`);

	if (!card || !status) return;

	card.classList.remove('sensor-alert');
	card.classList.add('sensor-normal');
	status.textContent = 'Normal';
}

// UPDATE THRESHOLD TABLE
async function loadSensorSettings() {
	if (!document.getElementById('tempMin')) return;

	try {
		const response = await fetch('api/settings.php');
		const result = await response.json();

		if (!result.success) return;

		result.thresholds.forEach(row => {
			const mid = Number(row.mid);

			if (mid === 0) {
				document.getElementById('tempMin').value = row.min_value;
				document.getElementById('tempMax').value = row.max_value;
			} else if (mid === 1) {
				document.getElementById('salinityMin').value = row.min_value;
				document.getElementById('salinityMax').value = row.max_value;
			} else if (mid === 2) {
				document.getElementById('phMin').value = row.min_value;
				document.getElementById('phMax').value = row.max_value;
			}
		});
	} catch (error) {
		console.error(error);
	}
}

async function saveSensorSettings() {
	const thresholds = [
		{
			mid: 0,
			min_value: document.getElementById('tempMin').value,
			max_value: document.getElementById('tempMax').value
		},
		{
			mid: 1,
			min_value: document.getElementById('salinityMin').value,
			max_value: document.getElementById('salinityMax').value
		},
		{
			mid: 2,
			min_value: document.getElementById('phMin').value,
			max_value: document.getElementById('phMax').value
		}
	];

	try {
		const response = await fetch('api/settings.php', {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({ thresholds })
		});

		const result = await response.json();

		const message = document.getElementById('settings-message');

		if (result.success) {
			message.style.color = '#3C91E6';
			message.textContent = result.message;
		} else {
			message.style.color = '#DB504A';
			message.textContent = result.message || 'Settings not saved.';
		}
	} catch (error) {
		document.getElementById('settings-message').style.color = '#DB504A';
		document.getElementById('settings-message').textContent = 'Cannot save settings to database.';
	}
}

// PROFILE FROM USER TABLE
async function loadProfile() {
	if (!document.getElementById('profile-form')) return;

	const savedUser = JSON.parse(localStorage.getItem('user') || '{"id":1}');
	try {
		const response = await fetch(`api/profile.php?id=${savedUser.id || 1}`);
		const result = await response.json();
		if (!result.user) return;

		setText('profile-username', result.user.username);
		document.getElementById('profile-email').value = result.user.email;
		document.getElementById('profile-phone').value = result.user.phone_no;
	} catch (error) {
		console.error(error);
	}
}

const profileForm = document.getElementById('profile-form');
if (profileForm) {
	profileForm.addEventListener('submit', async function (e) {
		e.preventDefault();
		const savedUser = JSON.parse(localStorage.getItem('user') || '{"id":1}');

		try {
			const response = await fetch('api/profile.php', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({
					id: savedUser.id || 1,
					email: document.getElementById('profile-email').value,
					phone_no: document.getElementById('profile-phone').value
				})
			});
			const result = await response.json();
			document.getElementById('profile-message').textContent = result.message || 'Profile saved';
		} catch (error) {
			document.getElementById('profile-message').textContent = 'Cannot save profile to database.';
		}
	});
}

async function checkSensorAlerts() {
	const alertBox = document.getElementById('alert-box');
	const alertList = document.getElementById('alert-list');
	const notificationNumber = document.querySelector('.notification .num');

	if (!alertBox || !alertList) return;

	try {
		const response = await fetch('api/alert.php');
		const result = await response.json();

		alertList.innerHTML = '';

		if (result.success && result.alert_count > 0) {
			alertBox.style.display = 'block';

			result.alerts.forEach(alert => {
				const li = document.createElement('li');
				li.textContent = alert.message;
				alertList.appendChild(li);
			});

			if (notificationNumber) {
				notificationNumber.textContent = result.alert_count;
			}
		} else {
			alertBox.style.display = 'none';

			if (notificationNumber) {
				notificationNumber.textContent = '0';
			}
		}

	} catch (error) {
		console.error('Failed to check alerts:', error);
	}
}


// USERS / TEAM PAGE
async function loadUsers() {
	const tbody = document.getElementById('team-table-body');
	if (!tbody) return;

	try {
		const response = await fetch('api/users.php');
		const result = await response.json();
		tbody.innerHTML = '';

		result.users.forEach(user => {
			const tr = document.createElement('tr');
			tr.innerHTML = `
				<td><img src="img/people.png"><p>${user.username}<br><small>${user.email}</small></p></td>
				<td>${user.phone_no}</td>
				<td><span class="role">User</span></td>
			`;
			tbody.appendChild(tr);
		});
	} catch (error) {
		tbody.innerHTML = '<tr><td colspan="3">Cannot load users from database.</td></tr>';
	}
}

function updateLiveBoxAlert(type, sensorData) {
	const card = document.getElementById(`${type}-card`);
	const status = document.getElementById(`${type}-status`);

	if (!card || !status || !sensorData) return;

	card.classList.remove('sensor-normal', 'sensor-alert');

	if (sensorData.alert_status === 'above' || sensorData.alert_status === 'below') {
		card.classList.add('sensor-alert');
		status.textContent = sensorData.alert_message;
	} else {
		card.classList.add('sensor-normal');
		status.textContent = 'Normal';
	}
}

window.addEventListener('DOMContentLoaded', function () {
	loadDashboard();
	loadSensorSettings();
	loadProfile();
	loadUsers();

	if (document.getElementById('temperatureChart')) {
		dashboardRefreshTimer = setInterval(loadDashboard, 10000);
	}
});
