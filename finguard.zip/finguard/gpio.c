
# include "global.h"


#define GPIO_SUCCESS      0
#define GPIO_ERROR_RANGE  0x1000
#define GPIO_ERROR_MODE   0x1001
#define GPIO_ERROR_STATE  0x1002

#if defined(__cplusplus)
extern "C"{
  #endif

uint16_t GPIO_MODE(uint8_t pin, uint8_t mode){
  uint8_t mask=0X01;

  if(pin > 13) return GPIO_ERROR_RANGE;
  if(mode > OUTPUT) return GPIO_ERROR_MODE;
  

  mask = mask << (pin & 7);
  /*switch(pin % 8){
    case 0: mask =0x01;  break;
    case 1: mask =0x02;  break;
    case 2: mask =0x04;  break;
    case 3: mask =0x08;  break;
    case 4: mask =0x10;  break;
    case 5: mask =0x20;  break;
    case 6: mask =0x40;  break;
    case 7: mask =0x80;  break;
  }*/
  

  if(pin > 7){
    if(mode == INPUT) DDRB = DDRB & ~mask;
    else DDRB = DDRB | mask;
  }
  else{
    if(mode == INPUT) DDRD = DDRD & ~mask;
    else DDRD = DDRD | mask;
  }

  return GPIO_SUCCESS;
}

uint16_t GPIO_WRITE(uint8_t pin, uint8_t state){
  uint8_t mask=0X01;

  if(pin > 13) return GPIO_ERROR_RANGE;
  if(state > HIGH) return GPIO_ERROR_STATE;

  mask = mask << (pin & 7);
  /*switch(pin % 8){
    case 0: mask =0x01;  break;
    case 1: mask =0x02;  break;
    case 2: mask =0x04;  break;
    case 3: mask =0x08;  break;
    case 4: mask =0x10;  break;
    case 5: mask =0x20;  break;
    case 6: mask =0x40;  break;
    case 7: mask =0x80;  break;
  }*/
  

  if(pin>7){
    if (state == LOW)  PORTB = PORTB & ~mask;
    else PORTB = PORTB | mask;
  }
  else{
    if(state == LOW) PORTD = PORTD & ~mask;
    else PORTD = PORTD | mask;
  }

  return GPIO_SUCCESS;
}

uint16_t GPIO_READ(uint8_t pin,uint8_t *value){ //*value maksudnya access value kat address tu
  uint8_t mask= 0x01;
  if(pin > 13) return GPIO_ERROR_RANGE;

  mask = mask << (pin & 7);

  if(pin > 7){   
    *value = (PINB & mask) ;
    if(*value > 0) *value=1;
  }
  else{
    *value = (PIND & mask);
    if(*value > 0) *value=1;

  }

  return GPIO_SUCCESS;

}



#if defined(__cplusplus)
}
#endif