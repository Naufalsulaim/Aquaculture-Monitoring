#include <stdio.h>
#include <arduino.h>
#include <stdint.h>
#include <avr/interrupt.h>
#include <string.h>
#include "gpio.h"
#include "timer1.h"
#include "timer2.h"
#include "timer0.h"
#include "adc.h"
#include "uart.h"
#include "swuart.h"
#include "DS18B20.h"
#include "tds.h"
#include "ble.h"
#include "phsensor.h"

#define SENSOR_ID    2

#define ERROR_CHECK_ENABLE 1

#if ERROR_CHECK_ENABLE == 1
  #define CHECK_ERROR_FATAL(x)  if((err_code=x) != 0) Error_Handler(err_code,__LINE__, __FILE__);
#else
  #define CHECK_ERROR_FATAL(x) x
#endif


#if defined(__cplusplus)
extern "C"{
#endif
extern void Error_Handler(uint16_t code, uint16_t line,char* file);

#if defined(__cplusplus)
}
#endif