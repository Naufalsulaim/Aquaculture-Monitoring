#define TIMER1_SUCCESS 0
#define TIMER1_ERROR_INT 0X4000

#if defined(__cplusplus)
extern "C"{
#endif

extern uint16_t TIMER1_init(void);
extern void TIMER1_Delay(uint16_t us);

#if defined(__cplusplus)
}
#endif
