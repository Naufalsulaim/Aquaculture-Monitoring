#include "global.h"

static uint16_t ADC_Value[ADC_BUF_SIZE]={0};
static uint8_t ADC_ptr = 0;
static uint32_t ADC_sum = 0;
char str[64];
  

uint32_t TDS_Init(void){
    uint8_t i;

    for(i = 0; i < ADC_BUF_SIZE; i++){
      ADC_Value[i] = 0;
    }

    ADC_ptr = 0;
    ADC_sum = 0;
    return TDS_SUCCESS;
}

uint32_t TDS_Read(float *TDS_ppm,float DS18B20_Temp){
  //filtering
  uint32_t ADC_avg;
  float voltage;
  float compensationCoefficient;
  float compensationVoltage;
  float TDS_Value;

  if(ADC_Value == NULL) return TDS_ERROR;


  ADC_sum -=  ADC_Value[ADC_ptr];
  ADC_Read(TDS_ANALOG_PIN, &ADC_Value[ADC_ptr]);
  if(ADC_Value[ADC_ptr] > 713) return TDS_INVALID_VALUE;
  ADC_sum += ADC_Value[ADC_ptr];
  ADC_avg =  ADC_sum / ADC_BUF_SIZE;
  ADC_ptr = (ADC_ptr + 1) & (ADC_BUF_SIZE - 1);
  //voltage conversion from adc read
  voltage = ((float) ADC_avg * VREF) / ADC_MAX;
  
  compensationCoefficient = 1.0 + 0.02 *(DS18B20_Temp-25.0);
  compensationVoltage= voltage/compensationCoefficient;
  TDS_Value=(133.42*compensationVoltage*compensationVoltage*compensationVoltage - 255.86*compensationVoltage*compensationVoltage + 857.39*compensationVoltage)*0.5;
  *TDS_ppm= TDS_Value;
  return TDS_SUCCESS;
}

