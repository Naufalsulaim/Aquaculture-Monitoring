<?php
header('Content-Type: application/json');

require_once 'db.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/../vendor/autoload.php';

$APP_NAME = 'FinGuard';

$SMTP_EMAIL = 'sofiabbst@gmail.com';
$SMTP_PASSWORD = 'ivzx lnpx wtxw egfy';

$FROM_EMAIL = 'sofiabbst@gmail.com';
$FROM_NAME = 'FinGuard Alert System';

$SEND_TO_ALL_USERS = true;


function normaliseType($type) {
    $type = strtolower(trim($type));

    if (str_contains($type, 'temp')) return 'Temperature';
    if (str_contains($type, 'sal')) return 'Salinity';
    if ($type === 'ph' || str_contains($type, 'ph')) return 'pH';

    return ucfirst($type);
}

function buildStateAlertEmailTemplate($alert) {
    $type = htmlspecialchars(normaliseType($alert['type']));
    $sensorName = htmlspecialchars($alert['sensor_name'] ?: 'Sensor ID ' . $alert['sid']);
    $location = htmlspecialchars($alert['location'] ?: '-');

    $value = (float)$alert['value'];
    $min = (float)$alert['min_value'];
    $max = (float)$alert['max_value'];
    $unit = htmlspecialchars($alert['unit'] ?? '');

    $readingTime = date("Y-m-d H:i:s", (int)$alert["timestamp"]);
    $sentTime = date("Y-m-d H:i:s");

    if ($alert['email_reason'] === 'active') {
        $title = "ACTIVE Sensor Alert";
        $bannerColor = "#e74c3c";
        $message = "A sensor value has exceeded the safe threshold.";
    } elseif ($alert['email_reason'] === 'reminder') {
        $title = "Alert Still Active";
        $bannerColor = "#f39c12";
        $message = "This alert is still active after 30 minutes.";
    } else {
        $title = "Alert Resolved";
        $bannerColor = "#2ecc71";
        $message = "The sensor value has returned to the safe range.";
    }

    if ($value < $min) {
        $status = "Too Low";
        $statusColor = "#f39c12";
    } elseif ($value > $max) {
        $status = "Too High";
        $statusColor = "#e74c3c";
    } else {
        $status = "Resolved / Normal";
        $statusColor = "#2ecc71";
    }

    return "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <title>FinGuard Alert</title>
    </head>
    <body style='margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f4f6f8;'>

        <div style='max-width: 800px; margin: 30px auto; background: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.08);'>

            <div style='background-color: {$bannerColor}; color: white; padding: 22px 28px;'>
                <h2 style='margin: 0;'>{$title}</h2>
                <p style='margin: 6px 0 0;'>FinGuard Aquaculture Water Quality Monitoring System</p>
            </div>

            <div style='padding: 28px;'>

                <p style='font-size: 15px; color: #333;'>{$message}</p>

                <table width='100%' cellpadding='10' cellspacing='0' style='border-collapse: collapse; font-size: 14px; margin-top: 20px;'>
                    <tr>
                        <td style='background: #f2f2f2; font-weight: bold;'>Measurement</td>
                        <td>{$type}</td>
                    </tr>
                    <tr>
                        <td style='background: #f2f2f2; font-weight: bold;'>Sensor</td>
                        <td>{$sensorName}</td>
                    </tr>
                    <tr>
                        <td style='background: #f2f2f2; font-weight: bold;'>Location</td>
                        <td>{$location}</td>
                    </tr>
                    <tr>
                        <td style='background: #f2f2f2; font-weight: bold;'>Measured Value</td>
                        <td><strong>{$value} {$unit}</strong></td>
                    </tr>
                    <tr>
                        <td style='background: #f2f2f2; font-weight: bold;'>Safe Range</td>
                        <td>{$min} {$unit} - {$max} {$unit}</td>
                    </tr>
                    <tr>
                        <td style='background: #f2f2f2; font-weight: bold;'>Status</td>
                        <td style='color: {$statusColor}; font-weight: bold;'>{$status}</td>
                    </tr>
                    <tr>
                        <td style='background: #f2f2f2; font-weight: bold;'>Reading Time</td>
                        <td>{$readingTime}</td>
                    </tr>
                    <tr>
                        <td style='background: #f2f2f2; font-weight: bold;'>Email Sent Time</td>
                        <td>{$sentTime}</td>
                    </tr>
                </table>

                <p style='margin-top: 28px; color: #777; font-size: 13px;'>
                    This is an automated alert notification from FinGuard.
                </p>

            </div>
        </div>

    </body>
    </html>
    ";
}


function sendAlertEmailSMTP($to, $subject, $body, $smtpEmail, $smtpPassword, $fromEmail, $fromName) {
    $mail = new PHPMailer(true);

    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = $smtpEmail;
    $mail->Password   = $smtpPassword;
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    $mail->setFrom($fromEmail, $fromName);
    $mail->addAddress($to);

    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body    = $body;
    $mail->AltBody = 'FinGuard Alert: One or more sensors exceeded the safe threshold. Please check the dashboard.';

    return $mail->send();
}

function buildAlertSubject($alert) {
    $type = normaliseType($alert['type']);

    if ($alert['email_reason'] === 'active') {
        return "[FinGuard ACTIVE Alert] {$type} threshold exceeded";
    }

    if ($alert['email_reason'] === 'reminder') {
        return "[FinGuard Reminder] {$type} alert still active after 30 minutes";
    }

    if ($alert['email_reason'] === 'resolved') {
        return "[FinGuard RESOLVED] {$type} back to normal";
    }

    return "[FinGuard Alert] Sensor threshold update";
}




try {
    $now = time();
    $REMINDER_SECONDS = 1800;

    $sql = "
        SELECT
            d.id AS data_id,
            d.sid,
            d.mid,
            d.timestamp,
            d.value,
            mt.type,
            mt.unit,
            t.min_value,
            t.max_value,
            s.name AS sensor_name,
            s.location
        FROM data d
        JOIN meas_t mt ON d.mid = mt.id
        JOIN threshold t ON t.mid = d.mid
        LEFT JOIN sensory s ON s.id = d.sid
        JOIN (
            SELECT sid, mid, MAX(timestamp) AS latest_timestamp
            FROM data
            GROUP BY sid, mid
        ) latest 
            ON latest.sid = d.sid 
            AND latest.mid = d.mid 
            AND latest.latest_timestamp = d.timestamp
        ORDER BY d.sid, d.mid
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $latestReadings = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $emailsToSend = [];

    foreach ($latestReadings as $reading) {
        $value = (float)$reading['value'];
        $min = (float)$reading['min_value'];
        $max = (float)$reading['max_value'];

        $isAlert = ($value < $min || $value > $max);
        $alertType = $value < $min ? 'too_low' : 'too_high';

        $activeStmt = $pdo->prepare("
            SELECT *
            FROM alert
            WHERE sid = ?
              AND mid = ?
              AND alert_state = 'active'
            ORDER BY id DESC
            LIMIT 1
        ");

        $activeStmt->execute([
            $reading['sid'],
            $reading['mid']
        ]);

        $activeAlert = $activeStmt->fetch(PDO::FETCH_ASSOC);

        // CASE 1: Value is alerting and no active alert exists
        if ($isAlert && !$activeAlert) {
            $insert = $pdo->prepare("
                INSERT INTO alert 
                (data_id, sid, mid, status_email, alert_state, alert_type, started_at, last_email_at, resolved_email_sent)
                VALUES (?, ?, ?, 'not received', 'active', ?, ?, NULL, 0)
            ");

            $insert->execute([
                $reading['data_id'],
                $reading['sid'],
                $reading['mid'],
                $alertType,
                $reading['timestamp']
            ]);

            $alertId = $pdo->lastInsertId();

            $reading['alert_id'] = $alertId;
            $reading['email_reason'] = 'active';

            $emailsToSend[] = $reading;
        }

        // CASE 2: Value is still alerting and alert already active (in 30 minutes)
        elseif ($isAlert && $activeAlert) {
            $lastEmailAt = $activeAlert['last_email_at'] 
                ? (int)$activeAlert['last_email_at'] 
                : (int)$activeAlert['started_at'];

            if (($now - $lastEmailAt) >= $REMINDER_SECONDS) {
                $reading['alert_id'] = $activeAlert['id'];
                $reading['email_reason'] = 'reminder';

                $emailsToSend[] = $reading;
            }

            $updateActive = $pdo->prepare("
                UPDATE alert
                SET data_id = ?, alert_type = ?
                WHERE id = ?
            ");

            $updateActive->execute([
                $reading['data_id'],
                $alertType,
                $activeAlert['id']
            ]);
        }

        // CASE 3: Value is normal again
        elseif (!$isAlert && $activeAlert) {
            $reading['alert_id'] = $activeAlert['id'];
            $reading['email_reason'] = 'resolved';

            $emailsToSend[] = $reading;
        }
    }

    if (count($emailsToSend) === 0) {
        echo json_encode([
            'success' => true,
            'message' => 'No new active, reminder, or resolved alert email needed.',
            'email_count' => 0
        ]);
        exit;
    }

    if ($SEND_TO_ALL_USERS) {
        $recipients = $pdo
            ->query("SELECT DISTINCT email FROM user WHERE email IS NOT NULL AND email != ''")
            ->fetchAll(PDO::FETCH_COLUMN);
    } else {
        $recipients = [$FIXED_RECEIVER_EMAIL];
    }

    if (empty($recipients)) {
        echo json_encode([
            'success' => false,
            'message' => 'Alert found, but no email recipient found.'
        ]);
        exit;
    }

    $sent = [];
    $failed = [];

    foreach ($emailsToSend as $alertEmail) {
        $subject = buildAlertSubject($alertEmail);
        $body = buildStateAlertEmailTemplate($alertEmail);

        foreach ($recipients as $recipient) {
            try {
                sendAlertEmailSMTP(
                    $recipient,
                    $subject,
                    $body,
                    $SMTP_EMAIL,
                    $SMTP_PASSWORD,
                    $FROM_EMAIL,
                    $FROM_NAME
                );

                $sent[] = [
                    'recipient' => $recipient,
                    'alert_id' => $alertEmail['alert_id'],
                    'reason' => $alertEmail['email_reason']
                ];

            } catch (Exception $e) {
                $failed[] = [
                    'recipient' => $recipient,
                    'alert_id' => $alertEmail['alert_id'],
                    'reason' => $alertEmail['email_reason'],
                    'error' => $e->getMessage()
                ];
            }
        }

        $wasSent = false;

        foreach ($sent as $sentItem) {
            if ($sentItem['alert_id'] == $alertEmail['alert_id']) {
                $wasSent = true;
                break;
            }
        }

        if ($wasSent) {
            if ($alertEmail['email_reason'] === 'active') {
                $update = $pdo->prepare("
                    UPDATE alert
                    SET status_email = 'received',
                        last_email_at = ?
                    WHERE id = ?
                ");

                $update->execute([
                    $now,
                    $alertEmail['alert_id']
                ]);
            }

            elseif ($alertEmail['email_reason'] === 'reminder') {
                $update = $pdo->prepare("
                    UPDATE alert
                    SET last_email_at = ?
                    WHERE id = ?
                ");

                $update->execute([
                    $now,
                    $alertEmail['alert_id']
                ]);
            }

            elseif ($alertEmail['email_reason'] === 'resolved') {
                $update = $pdo->prepare("
                    UPDATE alert
                    SET alert_state = 'resolved',
                        resolved_at = ?,
                        resolved_email_sent = 1
                    WHERE id = ?
                ");

                $update->execute([
                    $now,
                    $alertEmail['alert_id']
                ]);
            }
        }
    }

    echo json_encode([
        'success' => true,
        'message' => 'Alert email state check completed.',
        'email_count' => count($emailsToSend),
        'sent' => $sent,
        'failed' => $failed
    ]);

} catch (PDOException $e) {
    http_response_code(500);

    echo json_encode([
        'success' => false,
        'message' => 'Failed to process alert email state.',
        'error' => $e->getMessage()
    ]);
}
?>
