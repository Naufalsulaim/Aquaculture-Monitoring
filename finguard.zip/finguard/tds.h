#define TDS_SUCCESS        0
#define TDS_ERROR          0x7000
#define TDS_INVALID_VALUE  0x7001

#define TDS_ANALOG_PIN 0
#define TDS_ID         1

#define ADC_MAX           1023.0
#define VREF              3.3

#ifdef __cplusplus
extern "C" {
#endif

extern uint32_t TDS_Init(void);
extern uint32_t TDS_Read(float *TDS_ppm,float DS18B20_Temp);

#ifdef __cplusplus
}
#endif

